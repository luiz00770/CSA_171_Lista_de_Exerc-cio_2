﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Triângulo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Digite o valor do primeiro lado do triângulo: ");
            double a = double.Parse(Console.ReadLine());
            Console.Write("Digite o valor do segundo lado do triângulo: ");
            double b = double.Parse(Console.ReadLine());
            Console.Write("Digite o valor do terceiro lado do triângulo: ");
            double c = double.Parse(Console.ReadLine());

            if (a + b > c)
            {
                if(b + c > a)
                {
                    if (a + c > b)
                    {
                        if (a == b)
                        {
                            if (a == c)
                            {
                                Console.WriteLine("Triângulo equilátero");
                            }
                            else
                            {
                                Console.WriteLine("Triângulo isóceles");

                            }
                        }
                        else
                        { 
                            if (b == c)
                            {
                                Console.WriteLine("Triângulo isóceles");
                            }
                            else
                            {
                                Console.WriteLine("Triângulo escaleno");
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("Não forma um triângulo");
                    }
                }
                else
                {
                    Console.WriteLine("Não forma um triângulo");
                }
            }
            else
            {
                Console.WriteLine("Não forma um triângulo");
            }


        }
    }
}
