﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Triângulo_retângulo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Digite o valor do primeiro lado do triângulo: ");
            double a = double.Parse(Console.ReadLine());
            Console.Write("Digite o valor do segundo lado do triângulo: ");
            double b = double.Parse(Console.ReadLine());
            Console.Write("Digite o valor do terceiro lado do triângulo: ");
            double c = double.Parse(Console.ReadLine());

            double a2 = a * a;
            double b2 = b * b;
            double c2 = c * c;

            if (a2 + b2 == c2)
            {
                Console.WriteLine("Forma um triângulo retângulo");
            }
            else
            {
                if (a2 + c2 == b2)
                {
                    Console.WriteLine("Forma um triângulo retângulo");
                }
                else
                {
                    if (c2 + b2 == a2)
                    {
                        Console.WriteLine("Forma um triângulo retângulo");
                    }
                    else
                    {
                        Console.WriteLine("Não forma um triângulo retângulo");
                    }
                }

            }

        }
    }
}
