﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nota
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Write("Qual é a nota da sua P1: ");
            double p1 = double.Parse(Console.ReadLine());

            double p2 = (15 - p1) / 2;

            Console.WriteLine($"Sua nota deve ser de: {p2}");

             


        }
    }
}
