﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Média
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Qual é a nota da sua P1: ");
            double p1 = double.Parse(Console.ReadLine());

            Console.Write("Qual é a nota da sua P2: ");
            double p2 = double.Parse(Console.ReadLine());

            double m = (p1 + 2 * p2) / 3;

            if ( m  >= 5)
            {
                Console.WriteLine("Aprovado");
            }
            else
            {
                Console.WriteLine("Reprovado");
            }



        
        }
    }
}
